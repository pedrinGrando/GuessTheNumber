/**
 * 
 */
/**
 * @author Pedro
 *
 */
module CodigosTestes {
	requires java.desktop;
}